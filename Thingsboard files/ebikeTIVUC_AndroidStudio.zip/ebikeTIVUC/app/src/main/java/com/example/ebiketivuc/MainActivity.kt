package com.example.ebiketivuc

import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.ekn.gruzer.gaugelibrary.Range
import com.ingenieriajhr.blujhr.BluJhr
import kotlinx.android.synthetic.main.activity_main.*
import java.awt.font.NumericShaper

class MainActivity : AppCompatActivity() {


    //bluetooth var
    lateinit var blue: BluJhr
    var devicesBluetooth = ArrayList<String>()

    //visible ListView
    var graphviewVisible = true

    //nos almacena el estado actual de la conexion bluetooth
    var stateConn = BluJhr.Connected.False

    //sweet alert necesarios
    lateinit var loadSweet : SweetAlertDialog
    lateinit var errorSweet : SweetAlertDialog
    lateinit var okSweet : SweetAlertDialog
    lateinit var disconnection : SweetAlertDialog

    val range1ls = Range()
    val range2ls = Range()
    val range3ls = Range()

    val ranger = Range()

    val rangec = Range()
    val rangev = Range()
    val rangep = Range()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        range1ls.color = Color.parseColor("#00b20b")
        range1ls.from = 0.0
        range1ls.to = 30.0

        range2ls.color = Color.parseColor("#E3E500")
        range2ls.from = 30.0
        range2ls.to = 45.0

        range3ls.color = Color.parseColor("#ce0000")
        range3ls.from = 45.0
        range3ls.to = 60.0

        //add color ranges to gauge
        lsGraph.addRange(range1ls)
        lsGraph.addRange(range2ls)
        lsGraph.addRange(range3ls)


        //set min max and current value
        lsGraph.minValue = 0.0
        lsGraph.maxValue = 60.0
        lsGraph.value = 0.0

        ranger.color = Color.parseColor("#00b20b")
        ranger.from = 0.0
        ranger.to = 1000.0

        //add color ranges to gauge
        rGraph.addRange(ranger)

        //set min max and current value
        rGraph.minValue = 0.0
        rGraph.maxValue = 1000.0
        rGraph.value = 0.0

        rangec.color = Color.parseColor("#ce0000")
        rangec.from = 0.0
        rangec.to = 10.0

        rangev.color = Color.parseColor("#E3E500")
        rangev.from = 0.0
        rangev.to = 50.0

        rangep.color = Color.parseColor("#00b20b")
        rangep.from = 0.0
        rangep.to = 500.0

        bGraph.addRange(rangec)
        bGraph.addSecondRange(rangev)
        bGraph.addThirdRange(rangep)

        bGraph.minValue = 0.0
        bGraph.maxValue = 10.0
        bGraph.value = 0.0

        bGraph.secondMinValue = 0.0
        bGraph.secondMaxValue = 50.0
        bGraph.secondValue = 0.0

        bGraph.thirdMinValue = 0.0
        bGraph.thirdMaxValue = 500.0
        bGraph.thirdValue = 0.0

        //init var sweetAlert
        initSweet()

        blue = BluJhr(this)
        blue.onBluetooth()

        btnViewDevice.setOnClickListener {
            when (graphviewVisible) {
                false -> invisibleListDevice()
                true -> visibleListDevice()
            }
        }

        listDeviceBluetooth.setOnItemClickListener { adapterView, view, i, l ->
            if (devicesBluetooth.isNotEmpty()) {
                blue.connect(devicesBluetooth[i])
                //genera error si no se vuelve a iniciar los objetos sweet
                initSweet()
                blue.setDataLoadFinishedListener(object : BluJhr.ConnectedBluetooth {
                    override fun onConnectState(state: BluJhr.Connected) {
                        stateConn = state
                        when (state) {
                            BluJhr.Connected.True -> {
                                loadSweet.dismiss()
                                okSweet.show()
                                invisibleListDevice()
                                rxReceived()
                            }

                            BluJhr.Connected.Pending -> {
                                loadSweet.show()
                            }

                            BluJhr.Connected.False -> {
                                loadSweet.dismiss()
                                errorSweet.show()
                            }

                            BluJhr.Connected.Disconnect -> {
                                loadSweet.dismiss()
                                disconnection.show()
                                visibleListDevice()
                            }

                        }
                    }
                })
            }
        }

    }

    private fun rxReceived() {
        blue.loadDateRx(object:BluJhr.ReceivedData{
            override fun rxDate(rx: String) {
                if (rx.contains("l")) {
                    val datels = rx.replace("l", "")
                    //lstxt.text = date
                    lsGraph.value = datels.toDouble()
                }
                if (rx.contains("r")) {
                    val dater = rx.replace("r", "")
                    rGraph.value = dater.toDouble()
                }
                if (rx.contains("c")) {
                    val dater = rx.replace("c", "")
                    bGraph.value = dater.toDouble()
                }
                if (rx.contains("v")) {
                    val dater = rx.replace("v", "")
                    bGraph.secondValue = dater.toDouble()
                    bGraph.thirdValue = bGraph.value * bGraph.secondValue
                }
            }
        })
    }

    private fun initSweet() {
        loadSweet = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE)
        okSweet = SweetAlertDialog(this,SweetAlertDialog.SUCCESS_TYPE)
        errorSweet = SweetAlertDialog(this,SweetAlertDialog.ERROR_TYPE)
        disconnection = SweetAlertDialog(this,SweetAlertDialog.NORMAL_TYPE)

        loadSweet.titleText = "Conectando..."
        loadSweet.setCancelable(false)
        errorSweet.titleText = "Algo salió mal!!"

        okSweet.titleText = "Conectado"
        disconnection.titleText = "Desconectado"
    }

    /**
     * invisible listDevice
     */
    private fun invisibleListDevice() {
        containerGraph.visibility = View.VISIBLE
        containerDevice.visibility = View.GONE
        graphviewVisible = true
        btnViewDevice.text = "DISPOSITIVOS"
    }

    /**
     * visible list device
     */
    private fun visibleListDevice() {
        containerGraph.visibility = View.GONE
        containerDevice.visibility = View.VISIBLE
        graphviewVisible = false
        btnViewDevice.text = "VOLVER"

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!blue.stateBluetoooth() && requestCode == 100){
            blue.initializeBluetooth()
        }else{
            if (requestCode == 100){
                devicesBluetooth = blue.deviceBluetooth()
                if (devicesBluetooth.isNotEmpty()){
                    val adapter = ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,devicesBluetooth)
                    listDeviceBluetooth.adapter = adapter
                }else{
                    Toast.makeText(this, "No tienes vinculados dispositivos", Toast.LENGTH_SHORT).show()
                }

            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (blue.checkPermissions(requestCode,grantResults)){
            Toast.makeText(this, "Exit", Toast.LENGTH_SHORT).show()
            blue.initializeBluetooth()
        }else{
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.S){
                blue.initializeBluetooth()
            }else{
                Toast.makeText(this, "Algo salio mal", Toast.LENGTH_SHORT).show()
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

}